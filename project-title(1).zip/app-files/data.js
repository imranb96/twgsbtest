var APP_DATA = {
  "scenes": [
    {
      "id": "0-attachment-1",
      "name": "Attachment-1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.0845765424389135,
          "pitch": 0.7351632547850127,
          "rotation": 0.7853981633974483,
          "target": "1-attachment-1"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.5667102140887277,
          "pitch": -0.3860992209971279,
          "title": "Qur'an",
          "text": "<div>This is some sample text</div><div><br></div>"
        }
      ]
    },
    {
      "id": "1-attachment-1",
      "name": "Attachment-1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 1.3249064779067705,
        "pitch": -0.25724015244833787,
        "fov": 1.6147243140930472
      },
      "linkHotspots": [],
      "infoHotspots": [
        {
          "yaw": 1.3249064779067705,
          "pitch": -0.25724015244833787,
          "title": "To the windoowwww<br>",
          "text": "To the walllll<br>"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
